This contains a few scripts to test pytorch kernels that are relevant for quantization.
